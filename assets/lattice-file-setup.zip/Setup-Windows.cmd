@echo off
node "%~dp0tools\server-setup\setup.mjs"
if errorlevel 1 pause
