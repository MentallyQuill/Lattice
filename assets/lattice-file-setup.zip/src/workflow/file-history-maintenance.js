import {prepareDocumentCheckpoint} from './document-history.js?v=0.29.0';

/** Pure accepted-write projection. Call only within the backend's checked settlement. */
export async function prepareAcceptedFileMaintenance(snapshot,{scope,visibility,historyHandling}={}){
    if(historyHandling!==undefined&&!['replace','append'].includes(historyHandling))return {ok:false,error:{code:'INVALID_FILE_HANDLING',message:'Choose Replace or Append.'}};
    let value;try{if(snapshot.format==='json')value=JSON.parse(snapshot.content);}catch{}
    const clock=!!value?.clockId, outcomes=Array.isArray(value)&&value.length>0&&value.every(item=>item?.recordType==='random-outcome');
    const needed=snapshot.receipts.length>=224||clock&&((value.acceptedTimeAdvances?.length??0)>=24||(value.settledTimeEventIds?.length??0)>=768)||outcomes&&value.length>=192||historyHandling==='replace'&&(clock||outcomes);
    if(!needed)return {ok:true,data:{content:snapshot.content,receipts:snapshot.receipts,history:snapshot.history??{schemaVersion:1,epoch:0,head:null},pages:{}}};
    const prepared=await prepareDocumentCheckpoint(snapshot,{scope,visibility,checkpointId:'checkpoint:'+crypto.randomUUID()});
    if(!prepared.ok)return prepared;
    if(!Object.values(prepared.data.counts).some(count=>count>0))return {ok:true,data:{content:snapshot.content,receipts:snapshot.receipts,history:snapshot.history??{schemaVersion:1,epoch:0,head:null},pages:{}}};
    return {ok:true,data:{content:prepared.data.content,receipts:[],history:prepared.data.history,pages:prepared.data.pages}};
}
